package com.excelreader.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity

public class Employee {

    @Id
    private Integer employeeId;

    private String employeeName;

    private String employeeDesg;

    private Double employeeSalary;

    public Employee(Integer employeeId, String employeeName, String employeeDesg, Double employeeSalary) {
        this.employeeId = employeeId;
        this.employeeName = employeeName;
        this.employeeDesg = employeeDesg;
        this.employeeSalary = employeeSalary;
    }


    public Employee() {
    }


	public Integer getEmployeeId() {
		return employeeId;
	}


	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}


	public String getEmployeeName() {
		return employeeName;
	}


	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}


	public String getEmployeeDesg() {
		return employeeDesg;
	}


	public void setEmployeeDesg(String employeeDesg) {
		this.employeeDesg = employeeDesg;
	}


	public Double getEmployeeSalary() {
		return employeeSalary;
	}


	public void setEmployeeSalary(Double employeeSalary) {
		this.employeeSalary = employeeSalary;
	}

   
}
