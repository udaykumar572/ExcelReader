package com.excelreader.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.excelreader.entity.Employee;

public interface EmployeeRepo extends JpaRepository<Employee,Integer> {
}
