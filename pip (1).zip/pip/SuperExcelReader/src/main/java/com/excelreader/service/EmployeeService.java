package com.excelreader.service;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.excelreader.entity.Employee;
import com.excelreader.entity.EmployeeExcel;
import com.excelreader.helper.Helper;
import com.excelreader.repo.EmployeeRepo;
import com.excelreader.repo.ExcelRepo;



import java.io.IOException;
import java.util.List;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepo employeeRepo;
    
    @Autowired
    private ExcelRepo excelRepo;

    public void save(MultipartFile file) {

        try {
            List<Employee> employees = Helper.convertExcelToListOfProduct(file.getInputStream());
            this.employeeRepo.saveAll(employees);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public List<Employee> getAllEmployees() {
        return this.employeeRepo.findAll();
    }
    
    public void generateExcel(HttpServletResponse response) throws Exception {

		List<EmployeeExcel> employees = excelRepo.findAll();
		
		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.createSheet("Employees Data");
		XSSFRow row = sheet.createRow(0);
		
		row.createCell(0).setCellValue("EmployeeId");
		row.createCell(1).setCellValue("EmployeeName");
		row.createCell(2).setCellValue("EmployeeDesg");
		row.createCell(3).setCellValue("EmployeeSalary");
		

	/*	HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet("Courses Info");
		HSSFRow row = sheet.createRow(0);

		row.createCell(0).setCellValue("ID");
		row.createCell(1).setCellValue("Name");
		row.createCell(2).setCellValue("Price"); */

		int dataRowIndex = 1;
		
		for(EmployeeExcel excel : employees ) {
			
			XSSFRow dataRow = sheet.createRow(dataRowIndex);
			
			dataRow.createCell(0).setCellValue(excel.getEmployeeId());
			dataRow.createCell(1).setCellValue(excel.getEmployeeName());
			dataRow.createCell(1).setCellValue(excel.getEmployeeDesg());
			dataRow.createCell(2).setCellValue(excel.getEmployeeSalary());
			
			dataRowIndex++;
			
		}
		
		ServletOutputStream ops = response.getOutputStream();
		workbook.write(ops);
		workbook.close();
		ops.close();

	/*	for (Course course : courses) {
			HSSFRow dataRow = sheet.createRow(dataRowIndex);
			dataRow.createCell(0).setCellValue(course.getCid());
			dataRow.createCell(1).setCellValue(course.getName());
			dataRow.createCell(2).setCellValue(course.getPrice());
			dataRowIndex++;
		}

		ServletOutputStream ops = response.getOutputStream();
		workbook.write(ops);
		workbook.close();
		ops.close(); */

	}



}
