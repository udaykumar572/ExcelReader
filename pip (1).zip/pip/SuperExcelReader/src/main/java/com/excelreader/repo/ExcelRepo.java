package com.excelreader.repo;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;

import com.excelreader.entity.EmployeeExcel;


public interface ExcelRepo extends JpaRepository<EmployeeExcel, Serializable> {

}
